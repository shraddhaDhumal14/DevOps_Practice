scp -r vfradm@alonso.connex.ro:/infra/vfradm/hotfix/HOTFIX/DEXP/*/$1 $2
