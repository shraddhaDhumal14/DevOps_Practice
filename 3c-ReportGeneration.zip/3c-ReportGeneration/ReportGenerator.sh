#!/usr/bin/bash

html2="${2}/report.html"
rlpath=$2

##function to sort out code files from every given folder.
Codefiles () {
if [ -d "${rlpath}/${1}/${2}" ];then
        echo "<table>">> $html2
        echo "<tr>" >> $html2
        echo "<th style="width:40%">${2} App Files</th>" >> $html2
        echo '<th style="width:40%">Versions</th>' >> $html2
        echo "</tr>" >> $html2

        directoryPath="${rlpath}/${1}/${2}/INT"
        sorted_folder=($(find "${directoryPath}" -mindepth 1 -maxdepth 1 -type d -printf "%P\n" | sort))

        for folder in "${sorted_folder[@]}";
        do
                echo $folder
                folderpath="${directoryPath}/${folder}"
                sorted_file=`ls -A "${folderpath}" | sort | tail -1`
                OrigFileName=`echo "${sorted_file}" | cut -d '-' -f2`
                RestPart=`echo "${sorted_file}" | cut -d '-' -f1`
                SubRelease=`echo "${RestPart}" | cut -d '_' -f3`
                HotFix=`echo "${RestPart}" | cut -d '_' -f4`
                echo "<tr>" >> $html2
                echo "<td >$OrigFileName</td>" >> $html2
                echo "<td>$1--$SubRelease--HF_$HotFix</td>" >> $html2
                echo "</tr>" >> $html2
        done
        echo '</table>' >> $html2
        echo "</BR>" >> $html2
else
        echo "Do Nothing"
fi
}
##Function to sort DB files from DB folders
DBfiles () {
if [ -d "${rlpath}/${1}/${2}/DB" ];then
        echo "<table>">> $html2
        echo "<tr>" >> $html2
        echo "<th style="width:40%">${2} DB Files</th>" >> $html2
        echo '<th style="width:40%">Versions</th>' >> $html2
        echo "</tr>" >> $html2

        directoryPath="${rlpath}/${1}/${2}/DB"
        sorted_files=($(ls -1 "${directoryPath}" | grep -v total))

        for file in "${sorted_files[@]}";
        do
                echo $file
                OrigFileName=`echo "${file}" | cut -d '-' -f2`
                RestPart=`echo "${sorted_file}" | cut -d '-' -f1`
                SubRelease=`echo "${RestPart}" | cut -d '_' -f3`
                HotFix=`echo "${RestPart}" | cut -d '_' -f4`
                echo "<tr>" >> $html2
                echo "<td>$OrigFileName</td>" >> $html2
                echo "<td>$1--$SubRelease--HF_$HotFix</td>" >> $html2
                echo "</tr>" >> $html2
        done
        echo '</table>' >> $html2
        echo "</BR>" >> $html2
else
        echo "Do Nothing"
fi
}

##HTML Creation starts here
echo "<html>" >> $html2
echo "<style type="text/css">
table, th, td {
border: 1px solid black;
border-collapse: collapse;
font-family: Helvetica;:q
font-size: 12px;
}
th, td {
padding: 5px;
}
th {
background-color: #008080;
font-size: 14px;
}
td {
background-color: #FAF0E6;
}
p {
font-family: Helvetica;
font-size: 16px;
}
</style>" >> $html2

echo "<BR>" >> $html2
echo "<body>" >> $html2
echo "<p>" >> $html2
echo "Hello All," >> $html2
echo "<BR>" >> $html2
echo "PFB Consolidated View of the files to be deployed." >> $html2
echo "</p>" >> $html2
echo "<BR>" >> $html2
Codefiles $1 CRM
DBfiles $1 CRM
Codefiles $1 OMS
DBfiles $1 OMS
Codefiles $1 LMS
DBfiles $1 LMS
echo '<p>' >> $html2
echo "Regards," >> $html2
echo "<BR>" >> $html2
echo "DevOps Team" >> $html2
echo "</p>" >> $html2
echo "</body>" >> $html2
echo "</html>" >> $html2
echo "</body>" >> $html2
echo "</html>" >> $html2
