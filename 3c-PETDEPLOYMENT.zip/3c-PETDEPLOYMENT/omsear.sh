#!/bin/sh
set -x
file_name="$1"
WORKSPACE="$2"
folderpath="$3"

cd ${WORKSPACE}/3c/OmsEarChange;mkdir tmp1;mkdir tmp2;mkdir tmp3
cp ${file_name} tmp1
cd tmp1;jar -xf ${file_name};rm ${file_name};cp AutoLaunchMDB.jar ../tmp2; cp GhostOrderMdb.jar ../tmp3
cd ../tmp2;jar -xf AutoLaunchMDB.jar;cp ${WORKSPACE}/3c/OmsEarChange/weblogic-ejb-jar.xml META-INF;rm AutoLaunchMDB.jar;jar cmf ./META-INF/MANIFEST.MF AutoLaunchMDB.jar *;cp AutoLaunchMDB.jar ../tmp1
cd ../tmp3;jar -xf GhostOrderMdb.jar;cp ${WORKSPACE}/3c/OmsEarChange/weblogic-ejb-jar_ghost.xml META-INF;rm GhostOrderMdb.jar;jar cmf ./META-INF/MANIFEST.MF GhostOrderMdb.jar *;cp GhostOrderMdb.jar ../tmp1
cd ../tmp1;jar cf ${file_name} *;cp -p ${file_name} ${folderpath}
