scp -r vfradm@alonso.connex.ro:/infra/vfradm/releases/$1/$2 $3
