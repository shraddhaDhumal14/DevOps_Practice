#!/usr/bin/bash

set -x

#Capture arguments
release=$1
subrelease=$2
rlpath=$3

Sppath=`echo "$(dirname -- "$(readlink -f "${BASH_SOURCE}")")"`
echo $Sppath

#Remove first chareter and replace V with _##
rel=`echo $release | tr 'V' '_' | sed 's/^.//'`

if [ -d "${rlpath}/${release}" ]; then

        #Logic to scan files from code directories
        if [ -d "${rlpath}/${release}/${subrelease}" ];
        then
                #printf "SubRelease exists\n"
               mkdir -p $rlpath/SITCRMREPO
                DIRS=("OMS" "LMS" "CRM")

                printf "\n\n"
                for dir in ${DIRS[@]}
                do
                        if [ -d "${rlpath}/${release}/${subrelease}/INT/${dir}" ]
                        then
                                mkdir -p $rlpath/SITCRMREPO/$dir/INT
                                printf "Scanning code Files in directory - ${dir} \n"
                                cd "${rlpath}/${release}/${subrelease}/INT/${dir}"

                                #find and filter the tar file names and assign to an array
                                arr=( $(ls -lrt *tar* 2> /dev/null | awk 'NF {print $9}') )
                                printf ">> Found ${#arr[@]} tar.gz files \n"
                                for i in ${arr[@]};
                                do
                                        printf "\t --${i}\n"
                                done
                                for j in ${arr[@]};
                                do
                                        #arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | cut -d '/' -f2 | tr -s ' ') )
                                        arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | sed '1d') )
                                        printf ">> List of files found in ${j} \n"
                                        for z in ${arr1[@]};
                                        do
                                                printf  "\t --${z}\n"
                                                printf "afterline"
                                                filename=`echo $z | cut -d '/' -f2`
                                                HFName=`echo $z | cut -d '/' -f1`
                                                HFInt=`echo $HFName | sed 's/^.\{3\}//'`
                                                no_extension=${filename%%.*}
                                                printf "\n${no_extension}\n"
                                                extension=${filename#*.}
                                                printf "\n${extension}\n"
                                                if [[ ${extension} =~ .*README.* ]]
                                                then
                                                        echo "Do Nothing"
                                                elif [[ ${filename} == *'__'* ]]
                                                then
                                                        IFS='__'
                                                        read -ra parts <<< "${filename}"
                                                        for part in "${parts[@]}";
                                                        do
                                                                filenameUpdated="${parts[0]}"
                                                        done
                                                        unset IFS
                                                        if [[ ${filename} == *'pack.gz'* ]]
                                                        then
                                                                echo "File found with __"
                                                                mkdir -p $rlpath/SITCRMREPO/$dir/INT/${filenameUpdated}_Pack
                                                                tar -zxvf $rlpath/$release/$subrelease/INT/$dir/$j -C $rlpath/SITCRMREPO/$dir/INT/${filenameUpdated}_Pack $z --strip-components=1
                                                                mv $rlpath/SITCRMREPO/$dir/INT/${filenameUpdated}_Pack/$filename $rlpath/SITCRMREPO/$dir/INT/${filenameUpdated}_Pack/${rel}_${subrelease}_${HFInt}-$no_extension.${extension}
                                                                newfl=`basename $rlpath/SITCRMREPO/$dir/INT/${filenameUpdated}_Pack/${rel}_${subrelease}_${HFInt}-$no_extension.${extension}`
                                                                curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/$dir/INT/${filenameUpdated}_Pack/$newfl http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/${dir}/INT/${filenameUpdated}_Pack/${newfl}
                                                        else
                                                                mkdir -p $rlpath/SITCRMREPO/$dir/INT/$filenameUpdated
                                                                tar -zxvf $rlpath/$release/$subrelease/INT/$dir/$j -C $rlpath/SITCRMREPO/$dir/INT/$filenameUpdated $z --strip-components=1
                                                                mv $rlpath/SITCRMREPO/$dir/INT/$filenameUpdated/$filename $rlpath/SITCRMREPO/$dir/INT/$filenameUpdated/${rel}_${subrelease}_${HFInt}-$no_extension.${extension}
                                                                newfl=`basename $rlpath/SITCRMREPO/$dir/INT/$filenameUpdated/${rel}_${subrelease}_${HFInt}-$no_extension.${extension}`
                                                                curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/$dir/INT/$filenameUpdated/$newfl http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/${dir}/INT/$filenameUpdated/${newfl}
                                                        fi
                                                elif [[ ${extension} =~ ${no_extension} ]]
                                                then
                                                        mkdir -p $rlpath/SITCRMREPO/$dir/INT/$no_extension
                                                        tar -zxvf $rlpath/$release/$subrelease/INT/$dir/$j -C $rlpath/SITCRMREPO/$dir/INT/$no_extension $z --strip-components=1
                                                        mv $rlpath/SITCRMREPO/$dir/INT/$no_extension/$filename $rlpath/SITCRMREPO/$dir/INT/$no_extension/${rel}_${subrelease}_${HFInt}-$no_extension
                                                        newfl=`basename $rlpath/SITCRMREPO/$dir/INT/$no_extension/${rel}_${subrelease}_${HFInt}-$no_extension`
                                                        curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/$dir/INT/$no_extension/$newfl http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/${dir}/INT/${no_extension}/${newfl}      
                                                elif [[ ${filename} =~ .*db_schema_gen.* ]] || [[ ${filename} =~ .*ref_tables_list.* ]]
                                                then
                                                        mkdir -p $rlpath/SITCRMREPO/$dir/INT/SKIPPED
                                                        tar -zxvf $rlpath/$release/$subrelease/INT/$dir/$j -C $rlpath/SITCRMREPO/SKIPPED/ $z --strip-components=1
                                                        mv $rlpath/SITCRMREPO/SKIPPED/$filename $rlpath/SITCRMREPO/SKIPPED/${rel}_${subrelease}_${HFInt}-${no_extension}.${extension}
                                                        newfl=`basename $rlpath/SITCRMREPO/SKIPPED/${rel}_${subrelease}_${HFInt}-${no_extension}.${extension}`
                                                        curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/SKIPPED/$newfl http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/SKIPPED/${newfl}
                                                else
                                                        mkdir -p $rlpath/SITCRMREPO/$dir/INT/$no_extension
                                                        tar -zxvf $rlpath/$release/$subrelease/INT/$dir/$j -C $rlpath/SITCRMREPO/$dir/INT/$no_extension $z --strip-components=1
                                                        #mv $rlpath/SITCRMREPO/$dir/INT/$no_extension/$filename $rlpath/SITCRMREPO/$dir/INT/$no_extension/${no_extension}-${rel}-${subrelease}.${extension}
                                                        mv $rlpath/SITCRMREPO/$dir/INT/$no_extension/$filename $rlpath/SITCRMREPO/$dir/INT/$no_extension/${rel}_${subrelease}_${HFInt}-$no_extension.${extension}
                                                        #newfl=`basename $rlpath/SITCRMREPO/$dir/INT/$no_extension/${no_extension}-${rel}-${subrelease}.${extension}`
                                                        newfl=`basename $rlpath/SITCRMREPO/$dir/INT/$no_extension/${rel}_${subrelease}_${HFInt}-$no_extension.${extension}`
                                                        curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/$dir/INT/$no_extension/$newfl http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/${dir}/INT/${no_extension}/${newfl}
                                                fi
                                        done
                                done
                                printf "\n\n"
                                : '
                                if [ -z "$(ls -A ${rlpath}/SITCRMREPO)" ]
                                then
                                        echo "Do Nothing"
                                else
                                        cd $Sppath
                                        tar -zcvf INT-$dir-$rel-$subrelease.tar.gz -C $rlpath/SITCRMREPO/$dir/INT .
                                        curl -v -u admin:admin --upload-file INT-$dir-$rel-$subrelease.tar.gz http://10.78.195.214:8081/repository/CRM_SIT_REPO/${dir}/${release}/INT/INT-$dir-$rel-$subrelease.tar.gz
                                fi
                                '
                        else
                                printf "${dir} is not available hence no scanning of files \n\n"
                        fi
                done


                for dir in ${DIRS[@]}
                do
                        if [ -d "${rlpath}/${release}/${subrelease}/DB/${dir}" ]
                        then
                                mkdir -p $rlpath/SITCRMREPO/$dir/DB
                                printf "Scanning SQL Files in directory - ${dir} \n"
                                cd "${rlpath}/${release}/${subrelease}/DB/${dir}"

                                #find and filter the tar file names and assign to an array
                                arr=( $(ls -lrt *tar* 2> /dev/null | awk 'NF {print $9}') )
                                printf ">> Found ${#arr[@]} tar.gz files \n"
                                for i in ${arr[@]};
                                do
                                        printf "\t --${i}\n"
                                done
                                for j in ${arr[@]}
                                do
                                        #arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | cut -d '/' -f2 | tr -s ' ') )
                                        arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | sed '1d') )
                                        printf ">> List of files found in ${j} \n"
                                        for z in ${arr1[@]}
                                        do
                                                printf  "\t --${z}\n"

                                                #Logic to create new filename
                                                filename=`echo $z | cut -d '/' -f2`
                                                HFName=`echo $z | cut -d '/' -f1`
                                                HFInt=`echo $HFName | sed 's/^.\{3\}//'`
                                                no_extension=${filename%%.*}
                                                extension=${filename#*.}

                                                if [[ ${extension} =~ .*README.* ]]
                                                then
                                                        echo "Do Nothing"
                                                elif [[ ${filename} =~ .*db_schema_gen.* ]] || [[ ${filename} =~ .*ref_tables_list.* ]]
                                                then
                                                        mkdir -p $rlpath/SITCRMREPO/SKIPPED
                                                        tar -zxvf $rlpath/$release/$subrelease/DB/$dir/$j -C $rlpath/SITCRMREPO/SKIPPED/ $z --strip-components=1
                                                        mv $rlpath/SITCRMREPO/SKIPPED/$filename $rlpath/SITCRMREPO/SKIPPED/${rel}_${subrelease}_${HFInt}-${no_extension}.${extension}
                                                        newfl=`basename $rlpath/SITCRMREPO/SKIPPED/${rel}_${subrelease}_${HFInt}-${no_extension}.${extension}`
                                                        curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/SKIPPED/$newfl http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/SKIPPED/${newfl}
                                                else
                                                        tar -zxvf $rlpath/$release/$subrelease/DB/$dir/$j -C $rlpath/SITCRMREPO/$dir/DB/ $z --strip-components=1
                                                        #mv $rlpath/SITCRMREPO/$dir/DB/$filename $rlpath/SITCRMREPO/$dir/DB/${no_extension}-${HFInt}-${rel}-${subrelease}.${extension}
                                                        #newfl=`basename $rlpath/SITCRMREPO/$dir/DB/${no_extension}-${HFInt}-${rel}-${subrelease}.${extension}`
                                                        mv $rlpath/SITCRMREPO/$dir/DB/$filename $rlpath/SITCRMREPO/$dir/DB/${rel}_${subrelease}_${HFInt}-${no_extension}.${extension}
                                                        newfl=`basename $rlpath/SITCRMREPO/$dir/DB/${rel}_${subrelease}_${HFInt}-${no_extension}.${extension}`
                                                        printf "\t ${filename} || ${HFName} || ${HFInt} || ${newfl} \n"
                                                        curl -v -u jenkins.nexus:Password123 --upload-file $rlpath/SITCRMREPO/$dir/DB/$newfl http://devops03.connex.ro:8281/repository/crm_sit_repo/${release}/${dir}/DB/${newfl}

                                                fi
                                        done
                                done
                                printf "\n\n"
                                : '
                                if [ -z "$(ls -A ${rlpath}/SITCRMREPO/${dir}/DB)" ]
                                then
                                        echo "Do Nothing"
                                else
                                        cd $Sppath
                                        tar -zcvf DB-$dir-$rel-$subrelease.tar.gz -C $rlpath/SITCRMREPO/$dir/DB .
                                        curl -v -u admin:admin --upload-file DB-$dir-$rel-$subrelease.tar.gz http://10.78.195.214:8081/repository/CRM_SIT_REPO/${dir}/${release}/DB/DB-$dir-$rel-$subrelease.tar.gz
                                fi
                                '
                        else
                                printf "${dir} is not available hence no scanning of files \n\n"
                        fi

                done

                if [ -d "${rlpath}/SITCRMREPO" ]
                then
                        if [ -z "$(ls -A ${rlpath}/SITCRMREPO)" ]
                        then
                                echo "Do Nothing"
                        else
                                cd $Sppath
                                tar -zcvf $release-$subrelease.tar.gz -C ${rlpath}/SITCRMREPO --exclude "SKIPPED" .
                                curl -v -u jenkins.nexus:Password123 --upload-file $Sppath/$release-$subrelease.tar.gz http://devops03.connex.ro:8281/repository/CRM_SIT_REPO/${release}/ReleaseTar/$release-$subrelease.tar.gz
                        fi
                else
                        echo "Directory does not exists"
                fi

        else
                printf "SubRelease does not exists\n"
        fi
else
        printf "Release does not exists, eixting script \n"
fi
